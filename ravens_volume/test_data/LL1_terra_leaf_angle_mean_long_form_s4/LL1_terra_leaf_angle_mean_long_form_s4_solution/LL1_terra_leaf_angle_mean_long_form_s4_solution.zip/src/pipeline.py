
# coding: utf-8

# In[1]:

import os, sys, json
import pandas as pd
from d3mds import D3MDataset, D3MProblem, D3MDS
from sklearn.metrics import mean_absolute_error, mean_squared_error
import pyflux as pf
import numpy as np
import category_encoders as ce
from category_encoders import OneHotEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import Imputer
import numpy as np
from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix

def in_jyputer_notebook():
   try:
	   assert get_ipython().__class__.__name__=="ZMQInteractiveShell"
	   return True
   except:
	   return False

if in_jyputer_notebook(): 
   here = os.getcwd()
else:
   here = os.path.dirname(os.path.abspath(__file__))


# In[3]:


dspath = os.path.join(here, '..', '..', 'LL1_terra_leaf_angle_mean_long_form_s4_dataset')
prpath = os.path.join(here, '..', '..', 'LL1_terra_leaf_angle_mean_long_form_s4_problem')
solpath = os.path.join(here, '..')
assert os.path.exists(dspath)
assert os.path.exists(prpath)
d3mds = D3MDS(dspath, prpath)

X_train = d3mds.get_train_data()
y_train = d3mds.get_train_targets()

X_test = d3mds.get_test_data()
y_test = d3mds.get_test_targets()

print(X_train.shape, y_train.shape)
print(X_test.shape, y_test.shape)

target_name = d3mds.problem.get_targets()[0]['colName']

D = X_train.set_index(['cultivar','sitename'], drop=True)
print('----------- TRAIN: min day value counts ---------')
print(D.groupby(level=[0,1])['day'].min().value_counts())
print('----------- TRAIN: max day value counts ---------')
print(D.groupby(level=[0,1])['day'].max().value_counts())
D = X_test.set_index(['cultivar','sitename'], drop=True)
print('----------- TEST: predict day value counts ---------')
print(D.groupby(level=[0,1])['day'].min().value_counts())

# outlier analysis
# outlier_cultivar = X_test[X_test['day']==109]['cultivar'].values[0]
# outlier_sitename = X_test[X_test['day']==109]['sitename'].values[0]
# print(X_train[(X_train.cultivar==outlier_cultivar) & (X_train.sitename==outlier_sitename)]['day'])

def model_ARIMA(X_train, y_train, X_test, y_test):
	FLOOR=0.0
	CEILING=1.0
	train_df = X_train.copy()
	train_df[target_name]=y_train
	train_df.set_index(['cultivar','sitename'], drop=True, inplace=True)

	test_df = X_test.copy()
	test_df[target_name]=y_test
	test_df.set_index(['cultivar','sitename'], drop=True, inplace=True)

	y_pred = []
	y_pred_index = []
	y_pred_running_mean = None

	for i, (idx, df) in enumerate(train_df.groupby(level=[0,1])):
		print(i, end='.', flush=True) if i%100==0 else print('', end='.', flush=True)
		series = df[['day',target_name]]
		series.set_index('day', inplace=True)
		series_start_day = series.index.min()
		series_end_day = series.index.max()
		series_predict_day = test_df.loc[idx]['day']
		h = series_predict_day - series_end_day
		predicted_height = -1.0

		if series_predict_day in series.index:
			predicted_height = series.ix[series_predict_day][target_name]
		else:
			series = series.reindex(range(series_start_day, series_end_day+1), method='nearest')
			ar, ma, integ = 1,0,0
			model = pf.ARIMA(series, ar=ar, ma=ma, integ=integ, family=pf.Normal())
			mode_fit = model.fit('MLE')
			count = 0
			while series_predict_day not in series.index:
				series = series.append(model.predict(len(series)-max(ar,ma)))
				model = pf.ARIMA(series, ar=ar, ma=ma, integ=integ, family=pf.Normal())
				model_fit = model.fit('MLE')
				count+=1
				if count > 10:
					raise RuntimeError('could not find prediction day in 10 extensions!!!!!')
			predicted_height = series.ix[series_predict_day].values.tolist()[0]
		
		if predicted_height < FLOOR or predicted_height >= CEILING:
			print("*", end='')
			predicted_height = np.mean(y_pred)

		y_pred.append(predicted_height)
		y_pred_index.append(idx)
	
		# if i>100:
			# break

	y_truth = test_df.ix[y_pred_index][target_name].values.tolist()
	# print(y_pred)
	mae_score = mean_absolute_error(y_truth, y_pred)
	print('ARIMA performance MAE', mae_score)

	y_pred_df = pd.DataFrame(data=y_pred, index=X_test.index, columns=[target_name])
	y_pred_df.to_csv('predictions_ARIMA.csv')

	# y_truth_df = pd.DataFrame(data=y_truth, index=X_test.index, columns=[target_name])
	# y_truth_df.to_csv('truth_ARIMA.csv')

	scores_df = pd.DataFrame(data=[['meanAbsoluteError',mae_score]], columns=['metric','value'])
	scores_df.to_csv('scores_ARIMA.csv', index=None)


def model_regression_supplied(X_train, y_train, X_test, y_test):

	# create a simple pipeline to demonstrate proof-of-concept
	def run_simple_pipeline(X_train_in, 
	                        y_train_in, 
	                        X_test_in, 
	                        y_test_in,
	                        ignore_cols=None, 
	                        cat_cols=None):
	    X_train, y_train, X_test, y_test = X_train_in.copy(), y_train_in.copy(), X_test_in.copy(), y_test_in.copy()
	    if ignore_cols:
	        try:
	            X_train.drop(columns=ignore_cols, inplace=True)
	            X_test.drop(columns=ignore_cols, inplace=True)
	        except:
	        	raise

	    # print('train/test shapes...', X_train.shape, X_test.shape)
	    # print(X_train.columns)

	    category_encoder = ce.OneHotEncoder(cols=cat_cols)
	    X_train = category_encoder.fit_transform(X_train)
	    X_test = category_encoder.transform(X_test)

	    my_model = RandomForestRegressor(
	        random_state=42).fit(X_train, y_train)

	    y_pred = my_model.predict(X_test)
	    # Evaluate using cross valiidation
	    cv_score = cross_val_score(my_model, X_train, y_train, cv=5)
	    # Calculate an uncertainty score
	    conf_int = 1.96 * (cv_score.std()/np.sqrt(5))
	    # Compute Accuracy Scoremodel_regression() of fit model
	    score = my_model.score(X_test, y_test)
	    # Compute MAE
	    mae_score = mean_absolute_error(y_pred, y_test)
	    print('default score (R^2)', score)
	    print('CV mean:', cv_score.mean())
	    print('95% CI:', conf_int)
	    print('MAE score:', mae_score)
	    return y_pred, mae_score, my_model, X_train[:100]

	ignore_cols=[]
	cat_cols=['cultivar','sitename']
	(y_pred, mae_score, _, _) = run_simple_pipeline(X_train,y_train,X_test,y_test,ignore_cols=ignore_cols,cat_cols=cat_cols)

	y_pred_df = pd.DataFrame(data=y_pred, index=X_test.index, columns=[target_name])
	y_pred_df.to_csv('predictions_regression_supplied.csv')
	scores_df = pd.DataFrame(data=[['meanAbsoluteError',mae_score]], columns=['metric','value'])
	scores_df.to_csv('scores_regression_supplied.csv', index=None)


def model_predict_mean(y_train, X_test, y_test):
	y_train = np.array(y_train)
	mean = np.mean(y_train)
	y_pred = [mean]*len(y_test)
	mae_score = mean_absolute_error(y_pred, y_test)
	print('MAE score:', mae_score)

	y_pred_df = pd.DataFrame(data=y_pred, index=X_test.index, columns=[target_name])
	y_pred_df.to_csv('predictions_predict_mean.csv')
	scores_df = pd.DataFrame(data=[['meanAbsoluteError',mae_score]], columns=['metric','value'])
	scores_df.to_csv('scores_predict_mean.csv', index=None)

model_ARIMA(X_train, y_train, X_test, y_test)
model_regression_supplied(X_train, y_train, X_test, y_test)
model_predict_mean(y_train, X_test, y_test)
